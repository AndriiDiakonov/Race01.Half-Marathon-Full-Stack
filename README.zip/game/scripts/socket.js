let clientId = null;
var websoc = new WebSocket('ws://localhost:8080', 'echo-protocol');
websoc.onmessage = message => {
    //message.data
    const response = JSON.parse(message.data);
    console.log(response);
    //connect
    if (response.method == "connect") {
        clientId = response.clientId;
        console.log("Client id Set succesfully" + clientId)
    }
}
