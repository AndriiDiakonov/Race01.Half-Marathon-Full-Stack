"use strict";

const TYPE_SUCCESS = 'success';
const TYPE_ERROR = 'error';

module.exports.typeSuccess = TYPE_SUCCESS;
module.exports.typeError = TYPE_ERROR;
