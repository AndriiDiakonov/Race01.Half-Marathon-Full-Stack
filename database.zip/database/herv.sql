USE race01;

INSERT INTO cardTanos (name, health, attack, cost) VALUES ('Black Order acolyte', 1,1,0);
INSERT INTO cardTanos  (name, health, attack, cost) VALUES ('Black Order Solder', 2,1,1);
INSERT INTO cardTanos  (name, health, attack, cost) VALUES ('Black Order gunner', 3,2,2);
INSERT INTO cardTanos  (name, health, attack, cost) VALUES ('Сhitauri artillery', 1,5,3);
INSERT INTO cardTanos  (name, health, attack, cost) VALUES ('Sakaarans', 3,4,3);
INSERT INTO cardTanos  (name, health, attack, cost) VALUES ('Сhitauri Solder', 5,4,4);
INSERT INTO cardTanos  (name, health, attack, cost) VALUES ('Outriders', 2,6,4);
INSERT INTO cardTanos  (name, health, attack, cost) VALUES ('Chitauri Gorillas', 5,2,4);
INSERT INTO cardTanos  (name, health, attack, cost) VALUES ('Сhitauri Ship', 5,6,5);
INSERT INTO cardTanos  (name, health, attack, cost) VALUES ('Corvus Glaive', 4,7,5);
INSERT INTO cardTanos  (name, health, attack, cost) VALUES ('Ronan', 8,3,5);
INSERT INTO cardTanos  (name, health, attack, cost) VALUES ('Cull Obsidian', 8,4,6);
INSERT INTO cardTanos  (name, health, attack, cost) VALUES ('Proxima Midnight', 2,10,6);
INSERT INTO cardTanos  (name, health, attack, cost) VALUES ('Ebon Goiter', 3,9,7);
INSERT INTO cardTanos  (name, health, attack, cost) VALUES ('Leviathans', 10,2,8);


INSERT INTO cardIronMan  (name, health, attack, cost) VALUES ('Mark I', 2,2,1);
INSERT INTO cardIronMan  (name, health, attack, cost) VALUES ('Mark III', 2,3,2);
INSERT INTO cardIronMan  (name, health, attack, cost) VALUES ('Mark IV', 3,4,3);
INSERT INTO cardIronMan  (name, health, attack, cost) VALUES ('Mark IX', 5,2,3);
INSERT INTO cardIronMan  (name, health, attack, cost) VALUES ('Mark VI', 5,4,4);
INSERT INTO cardIronMan  (name, health, attack, cost) VALUES ('Mark XIII', 6,2,4);
INSERT INTO cardIronMan  (name, health, attack, cost) VALUES ('Mark XX', 1,7,4);
INSERT INTO cardIronMan  (name, health, attack, cost) VALUES ('Mark VII', 7,4,5);
INSERT INTO cardIronMan  (name, health, attack, cost) VALUES ('Mark X', 3,8,5);
INSERT INTO cardIronMan  (name, health, attack, cost) VALUES ('Mark XV', 8,2,5);
INSERT INTO cardIronMan  (name, health, attack, cost) VALUES ('Mark XI', 7,6,6);
INSERT INTO cardIronMan  (name, health, attack, cost) VALUES ('Mark XXXV', 10,4,6);
INSERT INTO cardIronMan  (name, health, attack, cost) VALUES ('Mark XXXVI', 10,4,7);
INSERT INTO cardIronMan  (name, health, attack, cost) VALUES ('Mark XXXVII', 7,9,7);
INSERT INTO cardIronMan  (name, health, attack, cost) VALUES ('Mark XLIV', 12,11,8);
